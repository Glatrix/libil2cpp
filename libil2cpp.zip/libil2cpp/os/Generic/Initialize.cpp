#include "il2cpp-config.h"
#include "os/Initialize.h"

#if !(IL2CPP_TARGET_WINDOWS || IL2CPP_TARGET_ANDROID || IL2CPP_TARGET_PS4 || IL2CPP_TARGET_PS5)

void il2cpp::os::Initialize()
{
}

void il2cpp::os::Uninitialize()
{
}

#endif
