#pragma once

#include "os/ReaderWriterLockImpl.h"

namespace il2cpp
{
namespace os
{
    class FastReaderReaderWriterLockImpl : public ReaderWriterLockImpl
    {
    };
}
}
