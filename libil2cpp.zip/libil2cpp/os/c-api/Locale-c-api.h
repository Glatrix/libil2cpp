#pragma once

#if defined(__cplusplus)
extern "C"
{
#endif

void UnityPalLocaleInitialize();
char* UnityPalGetLocale();

#if defined(__cplusplus)
}
#endif
