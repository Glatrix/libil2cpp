#include "il2cpp-config.h"
#include "MissingMemberException.h"

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace System
{
    Il2CppString* MissingMemberException::FormatSignature(Il2CppArray* signature)
    {
        IL2CPP_NOT_IMPLEMENTED_ICALL(MissingMemberException::FormatSignature);
        IL2CPP_UNREACHABLE;
        return NULL;
    }
} // namespace System
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
