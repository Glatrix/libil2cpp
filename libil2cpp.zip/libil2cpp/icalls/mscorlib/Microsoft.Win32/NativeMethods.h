#pragma once

namespace il2cpp
{
namespace icalls
{
namespace mscorlib
{
namespace Microsoft
{
namespace Win32
{
    class LIBIL2CPP_CODEGEN_API NativeMethods
    {
    public:
        static int32_t GetCurrentProcessId();
    };
} // namespace Win32
} // namespace Microsoft
} // namespace mscorlib
} // namespace icalls
} // namespace il2cpp
