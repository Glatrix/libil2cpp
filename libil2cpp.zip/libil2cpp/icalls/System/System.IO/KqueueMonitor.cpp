#include "il2cpp-config.h"
#include "KqueueMonitor.h"

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace System
{
namespace IO
{
    int32_t KqueueMonitor::kevent_notimeout(int32_t* kq, intptr_t ev, int32_t nchanges, intptr_t evtlist, int32_t nevents)
    {
        IL2CPP_NOT_IMPLEMENTED_ICALL(KqueueMonitor::kevent_notimeout);
        IL2CPP_UNREACHABLE;
        return 0;
    }
} // namespace IO
} // namespace System
} // namespace System
} // namespace icalls
} // namespace il2cpp
